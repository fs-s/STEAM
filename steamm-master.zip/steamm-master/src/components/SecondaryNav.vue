<template>
  <div class="flex flex-1 bg-secondaryBlue mx-64 my-10">
    <div class=" px-6 py-4 border-r-2 border-gray-800 bg-gradient-to-b hover:from-gray-400 hover:to-gray-500">
      <span class="text-white ">Sinu Pood</span>
    </div>
    <div class=" px-6 py-4 border-r-2 border-gray-800 bg-gradient-to-b hover:from-gray-400 hover:to-gray-500">
      <span class="text-white">Sirvi</span>
    </div>
    <div class=" px-6 py-4 border-r-2 border-gray-800 bg-gradient-to-b hover:from-gray-400 hover:to-gray-500">
      <span class="text-white">Punktide Pood</span>
    </div>
    <div class=" px-6 py-4 border-r-2 border-gray-800 bg-gradient-to-b hover:from-gray-400 hover:to-gray-500">
      <span class="text-white">Uudised</span>
    </div>
    <div class=" px-6 py-4 border-r-2 border-gray-800 bg-gradient-to-b hover:from-gray-400 hover:to-gray-500">
      <span class="text-white">Labor</span>
    </div>
    <div class="ml-auto p-4">
      <input type="text" name="search" placeholder="Otsi poest..." class="bg-blue-800 border-2 border-gray-800 rounded"/>
    </div>
  </div>
</template>


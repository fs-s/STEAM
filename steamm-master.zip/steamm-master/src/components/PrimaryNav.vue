<template>
  <div class="bg-navy-500 px-40 pt-2 pb-4 text-gray-500">
    <div class="flex items-center justify-end">
      <div class="bg-green-steam p-3 text-white mx-1">
        <a href="#" class="pl-10 pr-3 download-btn">paigalda aur</a>
      </div>
      <a href="#" class="mx-1 hover:text-white">sisene</a>
      <span class="mx-1 hover:text-white">keel</span>
    </div>
    <div class="flex-1 flex items-center">
      <img
        src="https://steamstore-a.akamaihd.net/public/shared/images/header/globalheader_logo.png?t=962016"
        alt="Steam logo"
      />
      <div>
        <a
          href="#"
          class="uppercase mx-4 no-underline text-gray-500 hover:text-white"
          >pood</a
        >
        <a
          href="#"
          class="uppercase mx-4 no-underline text-gray-500 hover:text-white"
          >kommun</a
        >
        <a
          href="#"
          class="uppercase mx-4 no-underline text-gray-500 hover:text-white"
          >meist</a
        >
        <a
          href="#"
          class="uppercase mx-4 no-underline text-gray-500 hover:text-white"
          >tugi</a
        >
      </div>
    </div>
  </div>
</template>
<style scoped>
.download-btn {
  background-image: url(https://steamstore-a.akamaihd.net/public/shared/images/header/btn_header_installsteam_download.png?v=1);
  background-position: 10px 2px;
  background-repeat: no-repeat;
}
</style>

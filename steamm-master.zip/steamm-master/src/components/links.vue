<template>
    <div class="text-gray-200 flex flex-col text-left ml-24 mt-40 text-sm">KINKEKAARDID
        <a href="#" class="text-blue-500 hover:text-white">Nüüd Olemas Steamis</a>
    </div>
    <div class="text-gray-200 flex flex-col text-left ml-24 my-5 text-sm">SOOVITATUD
        <a href="#" class="text-blue-500 hover:text-white">Sõprade Poolt</a>
        <a href="#" class="text-blue-500 hover:text-white">Kuraatorite poolt</a>
        <a href="#" class="text-blue-500 hover:text-white">Märksõnad</a>
    </div>
    <div class="text-gray-200 flex flex-col text-left ml-24 my-5 text-sm">AVASTUS JÄRJEKORD
        <a href="#" class="text-blue-500 hover:text-white">Soovitused</a>
        <a href="#" class="text-blue-500 hover:text-white">Uued Väljalased</a>
    </div>
    <div class="text-gray-200 flex flex-col text-left ml-24 my-5 text-sm">SIRVI KATEGOORIAID
        <a href="#" class="text-blue-500 hover:text-white">Enim Müünud</a>
        <a href="#" class="text-blue-500 hover:text-white">Uued Väljalased</a>
        <a href="#" class="text-blue-500 hover:text-white">Tulevased Mängud</a>
        <a href="#" class="text-blue-500 hover:text-white">Erilised</a>
        <a href="#" class="text-blue-500 hover:text-white">Virtuaal Reaalsus</a>
        <a href="#" class="text-blue-500 hover:text-white">Puldi Sõbralikud</a>
    </div>
    <div class="text-gray-200 flex flex-col text-left ml-24 my-5 text-sm">SIRVI ZANRI JÄRGI
        <a href="#" class="text-blue-500 hover:text-white">Tasuta</a>
        <a href="#" class="text-blue-500 hover:text-white">Varajane Ligipääs</a>
        <a href="#" class="text-blue-500 hover:text-white">Märul</a>
        <a href="#" class="text-blue-500 hover:text-white">Seiklus</a>
        <a href="#" class="text-blue-500 hover:text-white">Lihtne</a>
        <a href="#" class="text-blue-500 hover:text-white">Iseseisvad</a>
        <a href="#" class="text-blue-500 hover:text-white">Massiivne Mitmikmängija</a>
        <a href="#" class="text-blue-500 hover:text-white">Võidusõit</a>
        <a href="#" class="text-blue-500 hover:text-white">RPG</a>
        <a href="#" class="text-blue-500 hover:text-white">Simulatsioon</a>
        <a href="#" class="text-blue-500 hover:text-white">Sport</a>
        <a href="#" class="text-blue-500 hover:text-white">Strateegia</a>
    </div>
    <div class="text-gray-200 flex flex-col text-left ml-24 my-5 text-sm">VIIMATI VAADATUD
        <a href="#" class="text-blue-500 hover:text-white">Cyberpunk 2077</a>
    </div>

</template>